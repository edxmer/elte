import agentic.workflow.Agent;

public class Main {
    public static void main(String... args) {
        try {
            Agent a = Agent.loadAgent("agent-examples/study-coach.agent");
            a.run();
        } catch (Exception e) {}
    }
}