package agentic.workflow;

import agentic.workflow.llm.*;

public class WorkflowStep {
    private String name;
    public void setName(String name) { this.name = name; }
    public String getName() { return name; }

    private String prompt;
    public void setPrompt(String prompt) { this.prompt = prompt; }
    public String getPrompt() { return prompt; }

    private String systemPrompt;
    public void setSystemPrompt(String systemPrompt) { this.systemPrompt = systemPrompt; }
    public String getSystemPrompt() { return systemPrompt; }

    private StructuredOutput structuredOutput;
    public void setStructuredOutput(StructuredOutput structuredOutput) {
        this.structuredOutput = structuredOutput;
    }
    public StructuredOutput getStructuredOutput() {
        return structuredOutput;
    }

    public WorkflowStep(
        String name, 
        String prompt, 
        String systemPrompt,
        StructuredOutput structuredOutput
    ) throws IllegalArgumentException {
        if (
            name == null || name.isBlank() ||
            prompt == null || prompt.isBlank() ||
            systemPrompt == null || systemPrompt.isBlank() ||
            structuredOutput == null
        ) throw new IllegalArgumentException();

        this.name = name;
        this.prompt = prompt;
        this.systemPrompt = systemPrompt;
        this.structuredOutput = structuredOutput;
    }

    public boolean expectsStructuredOutput() {
        return 0 < structuredOutput.size();
    }

    public String simulateResponse() {
        switch (structuredOutput.getSchemaTypes()[0]) {
            case INT:
                return "0";
            case STRING:
                return "sample";
            case BOOLEAN:
                return "true";
            case LIST_INT:
                return "[1,2,3]";
            case LIST_STRING:
                return "[\"a\",\"b\"]";
            case MAP_STRING_STRING:
                return "{\"kulcs\":\"érték\"}";
        }
        return "";
    }
}
