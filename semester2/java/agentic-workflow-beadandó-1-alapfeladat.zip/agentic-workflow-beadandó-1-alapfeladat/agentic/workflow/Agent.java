package agentic.workflow;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import agentic.workflow.llm.SchemaType;
import agentic.workflow.llm.StructuredOutput;

public class Agent {
    private String name;
    private final List<WorkflowStep> steps;
    
    public void     setName(String name)    { this.name = name; }
    public String   getName()               { return name; }
    public List<WorkflowStep> getSteps() { return new ArrayList<WorkflowStep>(steps); }

    public Agent(String name)
    throws IllegalArgumentException {
        if (name == null || name.isBlank()) throw new IllegalArgumentException();
        this.name = name;
        steps = new ArrayList<WorkflowStep>();
    }

    public void addStep(WorkflowStep step)
    throws IllegalArgumentException {
        if (step == null) throw new IllegalArgumentException();
        for (WorkflowStep s: steps)
            if ( s.getName().equals(step.getName()) )
                throw new IllegalArgumentException();

        steps.add(step);
    }

    public int getStepCount() {
        return steps.size();
    }

    public WorkflowStep findStepByName(String stepName)
    throws IllegalArgumentException {
        if (stepName == null || stepName.isBlank()) throw new IllegalArgumentException();
        String strippedStepName = stepName.strip();

        for (WorkflowStep s: steps) {
            if (strippedStepName.equals(s.getName().strip())) return s;
        }
        return null;
    }

    public void run() {
        IO.println("RUNNING WORKFLOW FOR AGENT: %s".formatted(name));
        for (int i=0; i<steps.size();++i) {
            WorkflowStep step = steps.get(i);
            IO.println("---");
            IO.println("%2d.: %s".formatted(i+1, step.getName()));
            IO.println(" `%s`".formatted(step.simulateResponse()));
        }
    }

    public static Agent loadAgent(String filename)
    throws IllegalArgumentException, WorkflowFormatException, IOException {
        if (filename==null || filename.isBlank()) throw new IllegalArgumentException();
        
        try ( BufferedReader reader = new BufferedReader(new FileReader(filename)); ) {
            
            String[] tokens = reader.readLine().split(":");

            if (tokens == null || tokens.length != 2 || !tokens[0].strip().equals("AGENT"))
                throw new WorkflowFormatException("First line's format is not 'AGENT: ...'");
            
            Agent agent = new Agent(tokens[1].strip());
            
            String line; 
            while ( (line = reader.readLine()) != null) {
                if (!line.equals("STEP")) throw new WorkflowFormatException("Workflow step does not begin with 'STEP'");
                agent.addStep(parseStep(reader));
            }

            return agent;
        }
        catch (Exception e) { throw e; }
    }

    private static WorkflowStep parseStep(BufferedReader reader)
    throws IOException, WorkflowFormatException {
        String line;
        String name=null, prompt=null, systemPrompt=null;
        SchemaType type=null;
        
        while ( (line = reader.readLine()) != null ) {
            if (line.equals("ENDSTEP")) {
                if (name==null || prompt==null || systemPrompt==null || type==null) 
                    throw new WorkflowFormatException("Did not provide all necessary properties.");
                
                return new WorkflowStep(name, prompt, systemPrompt, new StructuredOutput(type));
            }

            String[] tokens = line.split("=");
            if (tokens == null || tokens.length != 2) 
                throw new WorkflowFormatException("Invalid format in a step: '%s'".formatted(line));
            tokens[1] = tokens[1].strip();
            
            switch (tokens[0].strip()) {
                case "name":
                    name = tokens[1];
                    break;
                case "prompt":
                    prompt = tokens[1];
                    break;
                case "systemPrompt":
                    systemPrompt = tokens[1];
                    break;
                case "output":
                    type = SchemaType.valueOf(tokens[1]);
                    break;
                default:
                    throw new WorkflowFormatException("Invalid format in a step: '%s'".formatted(line));
            }
        }
        throw new WorkflowFormatException("Invalid step format.");
    }
}