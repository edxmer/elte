package agentic.workflow.llm;

public class StructuredOutput {
    private final SchemaType[] schemaTypes;

    public SchemaType[] getSchemaTypes() {
        return schemaTypes.clone();
    } 
    
    public StructuredOutput(SchemaType... schemaTypes)
    throws IllegalArgumentException, NullPointerException {
        if (schemaTypes == null || schemaTypes.length == 0) throw new IllegalArgumentException();
        for (SchemaType t : schemaTypes) {
            if (t == null) throw new NullPointerException();
        }
        
        this.schemaTypes = schemaTypes.clone();
    }

    public boolean contains(SchemaType schemaType) {
        for (SchemaType t: schemaTypes) {
            if (t == schemaType) return true;
        }
        return false;
    }

    public int size() {
        return schemaTypes.length;
    }   
}
